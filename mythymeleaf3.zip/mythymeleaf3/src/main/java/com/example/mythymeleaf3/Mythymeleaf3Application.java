package com.example.mythymeleaf3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mythymeleaf3Application {

	public static void main(String[] args) {
		SpringApplication.run(Mythymeleaf3Application.class, args);
	}

}
