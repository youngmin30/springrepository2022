package com.jym.koreanedu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KoreaneduApplicationTests {

	@Test
	void contextLoads() {
	}

}
