package com.yhr.cleanCM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CleanCmApplicationTests {

	@Test
	void contextLoads() {
	}

}
