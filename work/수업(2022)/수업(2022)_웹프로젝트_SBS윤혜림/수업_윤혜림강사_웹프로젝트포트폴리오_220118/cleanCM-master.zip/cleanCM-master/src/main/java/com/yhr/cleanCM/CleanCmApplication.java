package com.yhr.cleanCM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CleanCmApplication {

	public static void main(String[] args) {
		SpringApplication.run(CleanCmApplication.class, args);
	}

}
