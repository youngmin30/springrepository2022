package com.yhr.cleanCM.dto;

import lombok.Data;

@Data
public class MemberLoginForm {

    private String loginId;

    private String loginPw;

}
