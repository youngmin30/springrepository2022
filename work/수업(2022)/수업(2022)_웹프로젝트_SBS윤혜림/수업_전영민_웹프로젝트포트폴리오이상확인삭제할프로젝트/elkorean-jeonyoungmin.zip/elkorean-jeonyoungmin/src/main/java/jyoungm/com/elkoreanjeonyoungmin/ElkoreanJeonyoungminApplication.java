package jyoungm.com.elkoreanjeonyoungmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElkoreanJeonyoungminApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElkoreanJeonyoungminApplication.class, args);
	}

}
